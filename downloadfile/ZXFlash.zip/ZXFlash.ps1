Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Initialize form
$form = New-Object System.Windows.Forms.Form
$form.Text = "ZXFlash USB Formatter"
$form.Size = New-Object System.Drawing.Size(400, 350)
$form.StartPosition = "CenterScreen"
$form.Topmost = $true

# Header Label - ZXFlash Branding
$lblHeader = New-Object System.Windows.Forms.Label
$lblHeader.Text = "Welcome to ZXFlash USB Formatter"
$lblHeader.Location = New-Object System.Drawing.Point(10, 10)
$lblHeader.Size = New-Object System.Drawing.Size(380, 30)
$lblHeader.Font = New-Object System.Drawing.Font("Arial", 14, [System.Drawing.FontStyle]::Bold)
$lblHeader.ForeColor = [System.Drawing.Color]::FromArgb(255, 0, 255)  # Vibrant Purple
$form.Controls.Add($lblHeader)

# Label - Instructions
$lblInstructions = New-Object System.Windows.Forms.Label
$lblInstructions.Text = "Select a USB drive, file system, and set a name:"
$lblInstructions.Location = New-Object System.Drawing.Point(10, 50)
$lblInstructions.Size = New-Object System.Drawing.Size(380, 20)
$form.Controls.Add($lblInstructions)

# Dropdown - USB Drives
$comboDrives = New-Object System.Windows.Forms.ComboBox
$comboDrives.Location = New-Object System.Drawing.Point(10, 80)
$comboDrives.Size = New-Object System.Drawing.Size(360, 20)
$form.Controls.Add($comboDrives)

# Label - File System
$lblFS = New-Object System.Windows.Forms.Label
$lblFS.Text = "File System:"
$lblFS.Location = New-Object System.Drawing.Point(10, 120)
$lblFS.Size = New-Object System.Drawing.Size(100, 20)
$form.Controls.Add($lblFS)

# Dropdown - File System
$comboFS = New-Object System.Windows.Forms.ComboBox
$comboFS.Items.AddRange(@("FAT32", "NTFS", "exFAT"))
$comboFS.SelectedIndex = 0
$comboFS.Location = New-Object System.Drawing.Point(120, 120)
$comboFS.Size = New-Object System.Drawing.Size(250, 20)
$form.Controls.Add($comboFS)

# Label - Volume Label
$lblVolName = New-Object System.Windows.Forms.Label
$lblVolName.Text = "Drive Name (Label):"
$lblVolName.Location = New-Object System.Drawing.Point(10, 160)
$lblVolName.Size = New-Object System.Drawing.Size(120, 20)
$form.Controls.Add($lblVolName)

# TextBox - Volume Label
$textVolLabel = New-Object System.Windows.Forms.TextBox
$textVolLabel.Location = New-Object System.Drawing.Point(140, 160)
$textVolLabel.Size = New-Object System.Drawing.Size(230, 20)
$form.Controls.Add($textVolLabel)

# Button - Format
$btnFormat = New-Object System.Windows.Forms.Button
$btnFormat.Text = "Format Drive"
$btnFormat.Location = New-Object System.Drawing.Point(10, 200)
$btnFormat.Size = New-Object System.Drawing.Size(360, 30)
$form.Controls.Add($btnFormat)

# Status Label
$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Text = ""
$lblStatus.Location = New-Object System.Drawing.Point(10, 250)
$lblStatus.Size = New-Object System.Drawing.Size(360, 60)
$lblStatus.ForeColor = "Red"
$form.Controls.Add($lblStatus)

# Fetch Removable Drives
function Get-RemovableDrives {
    Get-WmiObject Win32_Volume | Where-Object { $_.DriveType -eq 2 -and $_.DriveLetter } | ForEach-Object {
        $label = if ($_.Label) { $_.Label } else { "No Label" }
        $size = "{0:N1} GB" -f ($_.Capacity / 1GB)
        $display = "$($_.DriveLetter) - $label ($size)"
        [PSCustomObject]@{
            Display = $display
            DriveLetter = $_.DriveLetter
        }
    }
}

$global:usbDrives = Get-RemovableDrives
$comboDrives.Items.AddRange($usbDrives.Display)

# Format Logic
$btnFormat.Add_Click({
    $selectedIndex = $comboDrives.SelectedIndex
    if ($selectedIndex -lt 0) {
        [System.Windows.Forms.MessageBox]::Show("Please select a USB drive.")
        return
    }

    $driveLetter = $usbDrives[$selectedIndex].DriveLetter
    $fileSystem = $comboFS.SelectedItem
    $volumeLabel = $textVolLabel.Text.Trim()

    if ($volumeLabel.Length -gt 32) {
        [System.Windows.Forms.MessageBox]::Show("Drive name must be 32 characters or less.")
        return
    }

    $confirm = [System.Windows.Forms.MessageBox]::Show(
        "Are you sure you want to format drive $driveLetter as $fileSystem with label '$volumeLabel'?",
        "Confirm Format", "YesNo", "Warning"
    )
    if ($confirm -ne [System.Windows.Forms.DialogResult]::Yes) {
        return
    }

    try {
        $lblStatus.Text = "Formatting drive $driveLetter..."
        Format-Volume -DriveLetter $driveLetter.Replace(":", "") -FileSystem $fileSystem -NewFileSystemLabel $volumeLabel -Force -Confirm:$false
        $lblStatus.ForeColor = "Green"
        $lblStatus.Text = "Format complete!"
    } catch {
        $lblStatus.ForeColor = "Red"
        $lblStatus.Text = "Error: $_"
    }
})

# Run the form
$form.Add_Shown({ $form.Activate() })
[void]$form.ShowDialog()
